from aiozoom.components.meeting import Meeting
from aiozoom.components.dashboard import Dashboard


class Zoom(Meeting, Dashboard):
    pass
